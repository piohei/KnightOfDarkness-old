GG, Tlen and Jabber Mod
for Simple Machines Forum 1.1 RC 1-3, 1.1, 1.1.1, 1.1.2...
http://www.smf.pl/

made in Poland ;)

Based on Kemac's GGiTlen Mod, Jabber functionality added by blotko@gmail.com .
